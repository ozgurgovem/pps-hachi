# Handoff: 5N1K Tablosu (5W1H Problem Definition Table)

## Overview
A branded, print/deck-ready "5N1K" (Turkish 5W1H) problem-definition table used in Farplas
quality/production documentation. Six fixed rows — NE? / NEDEN? / NASIL? / NEREDE? / NE ZAMAN? / KİM? —
each a chevron-shaped question plate followed by a light answer panel. It replaces an ad-hoc
multi-colored PowerPoint graphic with a disciplined, design-system-grounded version.

## About the Design Files
The file in this bundle is a **design reference created in HTML** — a prototype showing the intended
look and behavior, not production code to copy directly. The task is to **recreate this design in the
target codebase's existing environment** (React, Vue, SwiftUI, native, etc.) using its established
patterns and libraries. If no environment exists yet, choose the most appropriate framework and
implement it there.

Note the source file is a "Design Component" (`.dc.html`): a template section plus a small logic class.
Read it as markup + data, not as a build target.

## Fidelity
**High-fidelity.** Final colors, typography, spacing and copy. Recreate pixel-accurately using the
codebase's existing libraries and the Farplas design tokens.

## Screens / Views

### 1. 5N1K Table (single view, no navigation)
- **Purpose**: Present the six 5N1K answers for one problem record in a single scannable block.
- **Layout**
  - Page wrapper: white background, `max-width: 980px`, centered (`margin: 0 auto`),
    `padding: 40px 32px`, `box-sizing: border-box`, `lang="tr"`.
  - Font stack: `'Segoe UI', 'Noto Sans', sans-serif`. Base text color `#53565A` (`--anthracite-700`).
  - Header block: `5N1K` title, `border-bottom: 2px solid #53565A`, `padding-bottom: 12px`,
    `margin-bottom: 4px`. Directly below it a red accent bar: `height: 3px; width: 88px;`
    `background: #ED212E` (`--red-600`), `margin-bottom: 28px`.
  - Rows: one CSS grid per row, `grid-template-columns: minmax(150px, 210px) minmax(0, 1fr)`,
    `gap: 0`, `align-items: stretch`, `margin-bottom: 10px`. The table reflows: label column
    shrinks to 150px, answer column takes the rest.

- **Components**

  **a) Title "5N1K"**
  - `font-size: 30px; font-weight: 900; letter-spacing: 0.04em; color: #1f2124`.
  - Verbatim text: `5N1K`. No subtitle, no department line (deliberately removed — do not invent
    header copy).

  **b) Question chevron (left cell)**
  - `position: relative; display: flex; align-items: center; justify-content: flex-end;`
  - `padding: 18px 34px 18px 20px; min-height: 62px; box-sizing: border-box`.
  - Arrow shape via
    `clip-path: polygon(0 0, calc(100% - 22px) 0, 100% 50%, calc(100% - 22px) 100%, 0 100%)`.
  - Fill: per-row color (see palette below). Sharp corners — no border radius anywhere.
  - Label: `font-size: 17px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase;`
    `color: #ffffff; text-align: right; line-height: 1.15`.
    Keep `lang="tr"` on an ancestor so uppercasing keeps Turkish dotted İ (İ, not I).
  - Row number: absolutely positioned, `left: 18px; top: 50%; transform: translateY(-50%);`
    `font-size: 12px; font-weight: 600; letter-spacing: 0.06em; color: #ffffff`.
    Values `01`–`06` (zero-padded). Full-opacity white is required for contrast — do not alpha it down.

  **c) Answer panel (right cell)**
  - `display: flex; align-items: center; background: #F5F4F2;`
    `border-left: 3px solid <row color>; padding: 18px 24px; box-sizing: border-box`.
  - Text: `font-size: 17px; font-weight: 400; line-height: 1.45; color: #33363a; text-wrap: pretty`.

## Content (verbatim — user-supplied, do not rewrite)
| # | Label | Answer |
|---|-------|--------|
| 01 | NE? | Yüksek fire oranı |
| 02 | NEDEN? | Enjeksiyon sapması |
| 03 | NASIL? | Sensör arızası ile çok uzun bir cevap metni burada yazıyor |
| 04 | NEREDE? | T2 enjeksiyon alanı |
| 05 | NE ZAMAN? | 15.07.2026 |
| 06 | KİM? | Proses Mühendisliği |

Answers are data: every one is a prop/field. Labels are fixed structure.

## Interactions & Behavior
- Static, non-interactive. No hover, focus, loading or error states, no animation, no navigation.
- Answer text wraps to multiple lines; the chevron and answer panel stretch together to the tallest
  content in the row (`align-items: stretch`, `min-height: 62px` floor on the chevron).
- Responsive: fluid down to narrow widths via `minmax()` columns and `max-width` (no fixed width).

## State Management
None. Pure presentational component driven by props:
- `ne, neden, nasil, nerede, neZaman, kim` — strings (the six answers).
- `monochrome` — boolean (default false): renders all six chevrons in anthracite tones instead of
  the three-brand-color ladder. For print/photocopy and single-color documents.
- `showNumbers` — boolean (default true): shows/hides the `01`–`06` row numbers.

## Design Tokens
From the Farplas design system (`tokens/colors.css`) — use the codebase's token equivalents, not literals:

Brand base palette
- `--red-600: #ED212E` (primary brand red), `--red-700: #B21924`
- `--teal-600: #01AEBC`, `--teal-700: #088F9C`
- `--anthracite-900: #3C3F42`, `--anthracite-700: #53565A`

Chevron row ladder (dark → light, two rows per brand color)
1. `--anthracite-900` → #3C3F42
2. `--anthracite-700` → #53565A
3. `color-mix(in srgb, var(--teal-700) 72%, #000)` ≈ #064F58
4. `color-mix(in srgb, var(--teal-700) 88%, #000)` ≈ #077E89
5. `--red-700` → #B21924
6. `color-mix(in srgb, var(--red-600) 84%, #000)` ≈ #C71C27

The mixes exist so 17px bold / 12px white label text clears 4.5:1 contrast on every fill; if you
substitute flat brand colors (#01AEBC, #ED212E) white text will fail contrast — keep the darkened stops.

Monochrome ladder: alternating `--anthracite-900` / `--anthracite-700`.

Surfaces & ink
- Page background: `#FFFFFF`
- Answer panel: `#F5F4F2` (close to `--gray-50: #F5F5F6`)
- Title ink `#1f2124`; answer ink `#33363a`; base text `#53565A`
- Header rule: 2px solid `#53565A`; accent bar 3px × 88px `#ED212E`; answer-panel left border 3px

Spacing
- Page padding 40px / 32px · row gap 10px (bottom margin) · cell padding 18px 24px
- Chevron padding 18px 34px 18px 20px · chevron point 22px · label column 150–210px

Typography
- 30px/900 title · 17px/700 uppercase +0.06em chevron label · 17px/400 1.45 answer · 12px/600 row number
- Family: Segoe UI → Noto Sans fallback (Google Fonts). Segoe UI has no redistributable webfont.

Radii & effects
- Border radius: 0 everywhere. No shadows, no gradients, no transparency. Flat by brand rule.

## Assets
None. No icons, no images, no SVG — the chevron is a CSS `clip-path`, the accent bar a div.
Do not add an icon set: the Farplas system has no icon language.

## Files
- `5N1K Tablosu.dc.html` — the design reference (template + logic class in one file).
  Chevron geometry and the row palette live in it; the six answers come from props with the
  verbatim defaults listed above.
- Design tokens: Farplas design system `tokens/colors.css`, `tokens/typography.css`,
  `tokens/spacing.css` (referenced, not bundled here).
